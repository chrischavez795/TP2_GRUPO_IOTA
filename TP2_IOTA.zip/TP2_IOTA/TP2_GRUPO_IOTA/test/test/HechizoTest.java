package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import fabrica.Reclutador;
import personaje.Personaje;
import hechizo.AvadaKedavra;
import hechizo.ExpectoPatronum;
import hechizo.Expelliarmus;
import hechizo.Hechizo;
import hechizo.Protego;
import personaje.DatosErroneosExcepcion;

public class HechizoTest {

	// Test 1: Verifica que el Expelliarmus haga daño.
	@Test
	void expelliarmusDebeReducirPuntosDeVida() throws DatosErroneosExcepcion {

		Personaje auror = Reclutador.crearAuror("Moody", 8, 120);
		Personaje mortifago = Reclutador.crearSeguidor("Seguidor", 5, 100);

		Hechizo hechizo = new Expelliarmus();

		hechizo.ejecutar(auror, mortifago);

		assertTrue(mortifago.getPuntosVida() < 100);
	}

	// Test 2: Verifica que Avada Kedavra haga más daño.
	@Test
	void avadaKedavraDebeGenerarGranDanio() throws DatosErroneosExcepcion {

		Personaje comandante = Reclutador.crearComandante("Bellatrix", 9, 130);
		Personaje enemigo = Reclutador.crearAuror("Moody", 8, 120);

		Hechizo hechizo = new AvadaKedavra();

		hechizo.ejecutar(comandante, enemigo);

		assertTrue(enemigo.getPuntosVida() < 70);
	}

	// Test 3: Verifica que Protego active la prote.
	@Test
	void protegoDebeReducirDanioRecibido() throws DatosErroneosExcepcion {

		Personaje defensor = Reclutador.crearAuror("Moody", 8, 120);
		Personaje atacante = Reclutador.crearSeguidor("Mortifago", 5, 100);

		Hechizo defensa = new Protego();
		Hechizo ataque = new Expelliarmus();

		defensa.ejecutar(defensor, defensor);

		int vidaInicial = defensor.getPuntosVida();

		ataque.ejecutar(atacante, defensor);

		int danio = vidaInicial - defensor.getPuntosVida();

		assertTrue(danio < 30);
	}

	// Test 4: Verifica que el Expecto Patronum regenere HP a un aliado.
	@Test
	void expectoPatronumDebeCurarPersonaje() throws DatosErroneosExcepcion {

		Personaje profesor = Reclutador.crearProfesor("McGonagall", 9, 110);

		profesor.recibirDanio(40);

		int vidaAntes = profesor.getPuntosVida();

		Hechizo cura = new ExpectoPatronum();

		cura.ejecutar(profesor, profesor);

		assertTrue(profesor.getPuntosVida() > vidaAntes);
	}

}