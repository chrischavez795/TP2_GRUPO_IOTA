package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import batalla.Batallon;
import fabrica.Reclutador;
import personaje.Personaje;
import personaje.DatosErroneosExcepcion;

public class BatallonTest {

	// Test 1: Verifica que el batallón pueda registrar personajes y que un personaje con vida sea considerado válido.
	@Test
	void debeAgregarPersonajesAlBatallon() throws DatosErroneosExcepcion {

		Batallon batallon = new Batallon();

		batallon.agregarPersonaje(Reclutador.crearAuror("Moody", 8, 120));

		assertTrue(batallon.tienePersonajesSaludables());
	}

	// Test 2: Verifica que un personaje al tener 0HP muera.
	@Test
	void personajeDerrotadoQuedaSinVida() throws Exception {

	    Batallon b1 = new Batallon();
	    Batallon b2 = new Batallon();

	    Personaje auror = Reclutador.crearAuror("Moody", 8, 1);
        Personaje mortifago = Reclutador.crearSeguidor("Morti", 5, 100);
        
	    b1.agregarPersonaje(auror);
	    b2.agregarPersonaje(mortifago);

	    b2.atacar(b1);

	    // El ataque debe haber matado al personaje
	    assertFalse(auror.estaVivo());
	}
	
	// Test 3: Verifica que el sistema ignore a personajes muertos.
	@Test
	void personajeDerrotadoNoPuedeSerAtacante() throws Exception {

	    Batallon b = new Batallon();

	    Personaje muerto = Reclutador.crearAuror("Muerto", 8, 0);
        Personaje vivo = Reclutador.crearAuror("Vivo", 8, 100);

	    b.agregarPersonaje(muerto);
	    b.agregarPersonaje(vivo);

	    assertEquals(vivo, b.obtenerSiguienteAtacanteVivo());
	}

	// Test 4: Valida que el batallón pueda detectar si todavía tiene personajes vivos.
	@Test
	void batallonDetectaPersonajesVivos() throws DatosErroneosExcepcion {

		Batallon batallon = new Batallon();

		batallon.agregarPersonaje(Reclutador.crearAuror("Moody", 8, 120));

		assertTrue(batallon.tienePersonajesSaludables());
	}
}