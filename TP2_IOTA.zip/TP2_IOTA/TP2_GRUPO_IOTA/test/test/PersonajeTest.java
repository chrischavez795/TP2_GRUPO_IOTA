package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import fabrica.Reclutador;
import personaje.Auror;
import personaje.Comandante;
import personaje.Personaje;
import personaje.DatosErroneosExcepcion;

public class PersonajeTest {

	// Test 1: Verifica que el constructor cree correctamente a un personaje.
	@Test
	void personajeDebeCrearseConDatosCorrectos() throws DatosErroneosExcepcion {

		Personaje p = Reclutador.crearAuror("Moody", 8, 120);

		assertEquals("Moody", p.getNombre());

		assertEquals(120, p.getPuntosVida());
	}

	// Test 2: Verifica las reglas de validación al crear personajes.
	@Test
	void noDebePermitirVidaNegativa() {

		assertThrows(DatosErroneosExcepcion.class, () -> {
			new Auror("Moody", 8, -10);
		});
	}

	// Test 3: Verifica que las clases hijas puedan modificar sus estadísticas mediante polimorfismo.
	@Test
	void aurorDebeTenerBonificacionAtaqueAlta() throws DatosErroneosExcepcion {

		Personaje auror = Reclutador.crearAuror("Moody", 8, 120);

		assertEquals(10, auror.obtenerBonificacionAtaque());
	}

	// Test 4: Verifica la mecánica del combate: recibir daño reduce HP.
	@Test
	void recibirDanioDebeReducirVida() throws DatosErroneosExcepcion {

		Personaje p = Reclutador.crearAuror("Moody", 8, 120);

		p.recibirDanio(50);

		assertEquals(70, p.getPuntosVida());
	}

	// -------------- BONUS --------------
	// Test 5: Verifica el comportamiento especial del Comandante: cuando un aliado
	// cae en batalla entra en estado de furia y aumenta temporalmente su
	// bonificacón oscura
	@Test
	void comandanteEntraEnFuriaCuandoMuereUnAliado() throws DatosErroneosExcepcion {

		Comandante comandante = (Comandante) Reclutador.crearComandante("Bellatrix", 9, 130);

		// Al inicio no debe estar enfurecido
		assertFalse(comandante.estaEnfurecido());

		// Simulamos la derrota de un aliado
		comandante.aliadoDerrotado();

		assertTrue(comandante.estaEnfurecido());
	}

	// Test 6: Verifica que la furia del comandante solo se aplique una vez.
	@Test
	void furiaDelComandanteSeConsumeAlAtacar() throws DatosErroneosExcepcion {

		Comandante comandante = (Comandante) Reclutador.crearComandante("Bellatrix", 9, 130);

		// Activamos furia
		comandante.aliadoDerrotado();

		int bonusConFuria = comandante.obtenerBonificacionOscura();
		int bonusNormal = comandante.obtenerBonificacionOscura();

		assertEquals(20, bonusConFuria);
		assertEquals(10, bonusNormal);
	}
}