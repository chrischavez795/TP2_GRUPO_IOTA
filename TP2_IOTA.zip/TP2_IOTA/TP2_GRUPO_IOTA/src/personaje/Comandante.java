package personaje;

public class Comandante extends Mortifago {

	private boolean enfurecido;
	
	public Comandante(String nombre, int nivelMagia, int puntosVida) throws DatosErroneosExcepcion {
		super(nombre, nivelMagia, puntosVida);
	}

	@Override
	public int obtenerBonificacionAtaque() {
		return BONIFICACION_MEDIA;
	}

	@Override
	public int obtenerBonificacionCuracion() {
		return BONIFICACION_BAJA;
	}

	@Override
	public int obtenerBonificacionOscura() {
		
		// Bonus: potencia su proximo ataque y se consume al usarlo
		if(enfurecido){
			enfurecido = false;
	        return BONIFICACION_ALTA + 10;
	    }
		
		return BONIFICACION_ALTA;
	}
	
	@Override
	public void aliadoDerrotado(){
	    enfurecido = true;
	    
	    System.out.println(nombre + " entra en estado de furia!");
	}
	
	public boolean estaEnfurecido(){
	    return enfurecido;
	}
}
