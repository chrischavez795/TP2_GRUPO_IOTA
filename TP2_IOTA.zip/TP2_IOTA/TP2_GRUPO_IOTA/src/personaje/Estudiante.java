package personaje;

public class Estudiante extends Mago {

	public Estudiante(String nombre, int nivelMagia, int puntosVida) throws DatosErroneosExcepcion {
		super(nombre, nivelMagia, puntosVida);
	}

	@Override
	public int obtenerBonificacionAtaque() {
		return BONIFICACION_BAJA;
	}

	@Override
	public int obtenerBonificacionDefensa() {
		return BONIFICACION_BAJA;
	}

	@Override
	public int obtenerBonificacionCuracion() {
		return BONIFICACION_BAJA;
	}

	@Override
	public int obtenerBonificacionOscura() {
		return BONIFICACION_BAJA;
	}
}
