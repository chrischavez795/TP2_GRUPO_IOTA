package personaje;

import hechizo.Hechizo;
import java.util.*;

public abstract class Personaje {

	protected String nombre;
	protected int nivelMagia;
	protected int puntosVida; 
	protected int puntosVidaMaximos;
	protected double proteccionActiva;
	protected List<Hechizo> listaHechizos;

	// Bonificadores de magia
	protected static final int BONIFICACION_ALTA = 10;
	protected static final int BONIFICACION_MEDIA = 5;
	protected static final int BONIFICACION_BAJA = -3;
	protected static final int SIN_BONIFICACION = 0;

	// Constructor
	public Personaje(String nombre, int nivelMagia, int puntosVida) throws DatosErroneosExcepcion {

		if (nombre == null || nombre.trim().isEmpty()) {
			throw new DatosErroneosExcepcion("El nombre del personaje esta vacio");
		}

		if (nivelMagia < 0) {
			throw new DatosErroneosExcepcion("El nivel de magia del personaje es menor que 0");
		}

		if (puntosVida < 0) {
			throw new DatosErroneosExcepcion("Los puntos de vida del personaje es menor que 0");
		}

		this.nombre = nombre;
		this.nivelMagia = nivelMagia;
		this.puntosVida = puntosVida;
		this.puntosVidaMaximos = puntosVida;
		this.proteccionActiva = 0;
		this.listaHechizos = new ArrayList<Hechizo>();
	}

	public String getNombre() {
		return nombre;
	}

	public int getNivelMagia() {
		return nivelMagia;
	}

	public int getPuntosVida() {
		return puntosVida;
	}

	public List<Hechizo> getListaHechizos() {
		return listaHechizos;
	}

	// DAÑO
	public void recibirDanio(double danioTotal) {

		int danioBloqueado = 0;

		if (this.proteccionActiva > 0) {
			danioBloqueado = (int) Math.min(danioTotal, this.proteccionActiva);
			System.out.println(this.nombre + " bloquea " + danioBloqueado + " puntos de daño con Protego.");
		}

		int danioReal = (int) (danioTotal - this.proteccionActiva);

		if (danioReal > 0) {
			this.puntosVida -= danioReal;

			if (this.puntosVida <= 0) {
				this.puntosVida = 0;
			}
		}

		this.proteccionActiva = 0;
	}

	// PROTECCION
	public void recibirProteccion(double proteccionRecibida) {

		if (proteccionRecibida > 0) {
			this.proteccionActiva = proteccionRecibida;
		}
	}

	// CURACION
	/*public void recibirCuracion(int curacionRecibida) {

	    if(curacionRecibida > 0) {

	        puntosVida += curacionRecibida;

	        if(puntosVida > puntosVidaMaximos) {
	            puntosVida = puntosVidaMaximos;
	        }
	    }
	}*/
	
	public void recibirCuracion(int curacionRecibida) {

		if (curacionRecibida <= 0) {
			return;
		}

		if (this.puntosVida >= this.puntosVidaMaximos) {
			System.out.println(this.nombre + " ya tiene la vida completa. No recibe curacion.");
			return;
		}

		int vidaAntes = this.puntosVida;

		this.puntosVida += curacionRecibida;

		if (this.puntosVida > this.puntosVidaMaximos) {
			this.puntosVida = this.puntosVidaMaximos;
		}

		int curacionReal = this.puntosVida - vidaAntes;

		System.out.println(this.nombre + " recupera " + curacionReal 
				+ " puntos de vida, teniendo en total " 
				+ this.puntosVida + " puntos de vida");
	}

	public boolean estaVivo() {
		return puntosVida > 0;
	}

	public int obtenerBonificacionAtaque() {
		return SIN_BONIFICACION;
	}

	public int obtenerBonificacionDefensa() {
		return SIN_BONIFICACION;
	}

	public int obtenerBonificacionCuracion() {
		return SIN_BONIFICACION;
	}

	public int obtenerBonificacionOscura() {
		return SIN_BONIFICACION;
	}

	public void agregarHechizo(Hechizo hechizo) {
		if (hechizo != null) {
			this.listaHechizos.add(hechizo);
		}
	}
	
	// BONUS: Personaje reactivo
	public void aliadoDerrotado(){
	}
	
	public void mostrarBonificaciones(){
	    System.out.println(nombre);
	    System.out.println("Ataque: " + obtenerBonificacionAtaque());
	    System.out.println("Defensa: " + obtenerBonificacionDefensa());
	    System.out.println("Curacion: " + obtenerBonificacionCuracion());
	    System.out.println("Oscura: " + obtenerBonificacionOscura());
	}

}
