package personaje;

public class Profesor extends Mago{
	
	public Profesor(String nombre, int nivelMagia, int puntosVida) throws DatosErroneosExcepcion{
		super(nombre, nivelMagia, puntosVida);
	}
	
	@Override
	public int obtenerBonificacionAtaque() {
	    return BONIFICACION_MEDIA;
	}

	@Override
	public int obtenerBonificacionDefensa() {
	    return BONIFICACION_ALTA;
	}

	@Override
	public int obtenerBonificacionCuracion() {
	    return BONIFICACION_MEDIA;
	}

	@Override
	public int obtenerBonificacionOscura() {
	    return BONIFICACION_BAJA;
	}
}
