package personaje;

public class DatosErroneosExcepcion extends Exception {

	private static final long serialVersionUID = 1L; // se agrega para sacar el warning

	public DatosErroneosExcepcion(String mensaje) {
		super(mensaje);
	}
}
