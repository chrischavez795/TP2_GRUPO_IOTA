package personaje;

public class Auror extends Mago {

	public Auror(String nombre, int nivelMagia, int puntosVida) throws DatosErroneosExcepcion {
		super(nombre, nivelMagia, puntosVida);
	}

	@Override
	public int obtenerBonificacionAtaque() {
		return BONIFICACION_ALTA;
	}

	@Override
	public int obtenerBonificacionOscura() {
		return BONIFICACION_BAJA;
	}
}
