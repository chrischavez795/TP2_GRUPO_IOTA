package personaje;

public abstract class Mortifago extends Personaje {

	public Mortifago(String nombre, int nivelMagia, int puntosVida) throws DatosErroneosExcepcion {
		super(nombre, nivelMagia, puntosVida);
	}

}
