package personaje;

public abstract class Mago extends Personaje {

	public Mago(String nombre, int nivelMagia, int puntosVida) throws DatosErroneosExcepcion {
		super(nombre, nivelMagia, puntosVida);
	}
}
