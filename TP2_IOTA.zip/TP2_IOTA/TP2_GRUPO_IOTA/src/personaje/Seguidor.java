package personaje;

public class Seguidor extends Mortifago {

	public Seguidor(String nombre, int nivelMagia, int puntosVida) throws DatosErroneosExcepcion {
		super(nombre, nivelMagia, puntosVida);
	}

	@Override
	public int obtenerBonificacionAtaque() {
		return SIN_BONIFICACION;
	}

	@Override
	public int obtenerBonificacionCuracion() {
		return BONIFICACION_BAJA;
	}

	@Override
	public int obtenerBonificacionOscura() {
		return BONIFICACION_ALTA;
	}
}
