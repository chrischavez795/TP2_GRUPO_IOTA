package hechizo;

import personaje.Personaje;

// Tipo de hechizo: Curación
// Curación base: 25
// Curación total = curación base + bonificacion por nivel de magia del lanzador
//             + bonificación de curación según el tipo de personaje
// Formula: CURACION_BASE + (lanzador.getNivelMagia() * 2) + lanzador.obtenerBonificacionCuracion()

public class ExpectoPatronum extends HechizoBase {

	private static final int CURACION_BASE = 25;

	public ExpectoPatronum() {
	}

	@Override
	public void ejecutar(Personaje lanzador, Personaje objetivo) {

		int curacionTotal = 0;

		curacionTotal = CURACION_BASE + (lanzador.getNivelMagia() * 2) + lanzador.obtenerBonificacionCuracion();

		objetivo.recibirCuracion(curacionTotal);
	}

	@Override
	public TipoObjetivo getTipoObjetivo() {
		return TipoObjetivo.ALIADO;
	}

	@Override
	public String getNombre() {
		return "ExpectoPatronum";
	}
}
