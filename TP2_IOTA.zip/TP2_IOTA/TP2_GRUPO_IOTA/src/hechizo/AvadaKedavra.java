package hechizo;

import personaje.Personaje;

// Tipo de hechizo: Ataque Oscuro
// Daño base: 50
// Daño total = daño base + bonificación por nivel de magia del lanzador
//           + bonificaciçon oscura según el tipo de personaje
// Formula: DANIO_BASE + (lanzador.getNivelMagia() * 3) + lanzador.obtenerBonificacionOscura()

public class AvadaKedavra extends HechizoBase {

	private static final int DANIO_BASE = 50;

	public AvadaKedavra() {
	}

	@Override
	public void ejecutar(Personaje lanzador, Personaje objetivo) {

		double danioTotal = 0;

		danioTotal = DANIO_BASE + (lanzador.getNivelMagia() * 3) + lanzador.obtenerBonificacionOscura();

		if (danioTotal < 0) {
			danioTotal = 0;
		}

		objetivo.recibirDanio(danioTotal);
	}

	@Override
	public TipoObjetivo getTipoObjetivo() {
		return TipoObjetivo.ENEMIGO;
	}

	@Override
	public String getNombre() {
		return "AvadaKedavra";
	}

}
