package hechizo;

import personaje.Personaje;

// Tipo de hechizo: Ataque
// Daño base: 20
// Daño total = daño base + bonificacion por nivel de magia del lanzador
//           + bonificacion de ataque segun el tipo de personaje
// Formula: DANIO_BASE + (lanzador.getNivelMagia() * 2) + lanzador.obtenerBonificacionAtaque()

public class Expelliarmus extends HechizoBase {

	private static final int DANIO_BASE = 20;

	public Expelliarmus() {}

	@Override
	public void ejecutar(Personaje lanzador, Personaje objetivo) {

		double danioTotal = 0;

		danioTotal = DANIO_BASE + (lanzador.getNivelMagia() * 2) + lanzador.obtenerBonificacionAtaque();

		if (danioTotal < 0) {
			danioTotal = 0;
		}

		objetivo.recibirDanio(danioTotal);

	}

	@Override
	public TipoObjetivo getTipoObjetivo() {
		return TipoObjetivo.ENEMIGO;
	}

	@Override
	public String getNombre() {
		return "Expelliarmus";
	}
}
