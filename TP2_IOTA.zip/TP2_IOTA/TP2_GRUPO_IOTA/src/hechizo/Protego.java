package hechizo;

import personaje.Personaje;

// Tipo de hechizo: Defensa (reduce el proximo daño recibido)
// Proteccion base: 20
// Proteccion total = protección base + bonificacion por nivel de magia del lanzador
//               + bonificacion defensiva segun el tipo de personaje
// Formula: PROTECCION_BASE + (lanzador.getNivelMagia() * 2) + lanzador.obtenerBonificacionDefensa()

public class Protego extends HechizoBase {

	private static final int PROTECCION_BASE = 20;

	public Protego() {}

	@Override
	public void ejecutar(Personaje lanzador, Personaje objetivo) {

		double proteccionTotal = 0;

		proteccionTotal = PROTECCION_BASE + (lanzador.getNivelMagia() * 2) + lanzador.obtenerBonificacionDefensa();

		lanzador.recibirProteccion(proteccionTotal);
	}

	@Override
	public TipoObjetivo getTipoObjetivo() {
		return TipoObjetivo.PROPIO;
	}

	@Override
	public String getNombre() {
		return "Protego";
	}
}
