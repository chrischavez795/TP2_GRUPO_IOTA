package hechizo;

import personaje.Personaje;

public interface Hechizo {

	public enum TipoObjetivo {
		ENEMIGO, ALIADO, PROPIO
	}

	public void ejecutar(Personaje lanzador, Personaje objetivo);

	TipoObjetivo getTipoObjetivo();

	String getNombre();
}
