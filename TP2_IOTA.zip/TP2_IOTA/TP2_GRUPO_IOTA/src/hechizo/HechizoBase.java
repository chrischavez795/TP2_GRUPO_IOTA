package hechizo;

public abstract class HechizoBase implements Hechizo {

	@Override
	public boolean equals(Object obj) {

		if (this == obj)
			return true;

		if (!(obj instanceof Hechizo))
			return false;

		Hechizo otro = (Hechizo) obj;

		return this.getNombre().equals(otro.getNombre());
	}

	@Override
	public int hashCode() {
		return getNombre().hashCode();
	}

}