package main;

import java.util.Random;

import batalla.Batallon;
import fabrica.*;
import personaje.*;

public class Main {

	public static void main(String[] args) {

		try {
			Batallon magos = new Batallon();
			Batallon mortifagos = new Batallon();

			Personaje auror = Reclutador.crearAuror("Alastor Moody", 8, 120);
			Personaje estudiante = Reclutador.crearEstudiante("Neville", 4, 90);
			Personaje profesor = Reclutador.crearProfesor("McGonagall", 9, 110);

			Personaje seguidor1 = Reclutador.crearSeguidor("Mortifago 1", 5, 35);
			Personaje seguidor2 = Reclutador.crearSeguidor("Mortifago 2", 5, 35);
			Personaje comandante = Reclutador.crearComandante("Bellatrix", 9, 130);

			magos.agregarPersonaje(auror);
			magos.agregarPersonaje(estudiante);
			magos.agregarPersonaje(profesor);

			mortifagos.agregarPersonaje(seguidor1);
			mortifagos.agregarPersonaje(seguidor2);
			mortifagos.agregarPersonaje(comandante);

			System.out.println("--- BONIFICACIONES AUROR ---");
			auror.mostrarBonificaciones();
			System.out.println("--- BONIFICACIONES COMANDANTE ---");
			comandante.mostrarBonificaciones();

			System.out.println("========== ESTADO INICIAL ==========");
			System.out.println("--- STATS MAGOS ---");
			magos.mostrarEstado();
			System.out.println("--- STATS MORTIFAGOS ---");
			mortifagos.mostrarEstado();

			Random random = new Random();

			int ronda = 1;

			while (magos.tienePersonajesSaludables() && mortifagos.tienePersonajesSaludables()) {

				System.out.println("========== RONDA " + ronda + " ==========");

				if (random.nextBoolean()) {

					System.out.println("--- Atacan primero los magos ---");
					magos.atacarTodos(mortifagos);

					if (mortifagos.tienePersonajesSaludables()) {
						System.out.println("--- Responden los mortifagos ---");
						mortifagos.atacarTodos(magos);
					}

				} else {
				System.out.println("--- Atacan primero los mortifagos ---");
					mortifagos.atacarTodos(magos);

					if (magos.tienePersonajesSaludables()) {
						System.out.println("--- Responden los magos ---");
						magos.atacarTodos(mortifagos);
					}

				}

				System.out.println("--- STATS MAGOS ---");
				magos.mostrarEstado();
				System.out.println("--- STATS MORTIFAGOS ---");
				mortifagos.mostrarEstado();

				magos.reiniciarRonda();
				mortifagos.reiniciarRonda();

				System.out.println("----------------------------");
				ronda++;
			}

			if (magos.tienePersonajesSaludables()) {
				System.out.println("¡Los magos han ganado la batalla!");
			} else {
				System.out.println("¡Los mortifagos han ganado la batalla!");
			}

		} catch (DatosErroneosExcepcion e) {
			System.out.println("Error al crear personajes: " + e.getMessage());
		}
	}
}