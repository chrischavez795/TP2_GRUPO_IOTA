package fabrica;

import hechizo.Expelliarmus;
import hechizo.Hechizo;

public class CreadorExpelliarmus implements CreadorHechizo{
	
	@Override
	public Hechizo crearHechizo() {
		return new Expelliarmus();
	}

}
