package fabrica;

import personaje.DatosErroneosExcepcion;
import personaje.*;

public class CreadorComandante implements CreadorPersonaje{
	
	@Override
	public Personaje crearPersonaje(String nombre, int nivelMagia, int puntosVida) throws DatosErroneosExcepcion{
		
		Personaje comandante = new Comandante(nombre, nivelMagia, puntosVida);
		
		// hechizos iniciales
		comandante.agregarHechizo(new CreadorAvadaKedavra().crearHechizo());
		comandante.agregarHechizo(new CreadorExpelliarmus().crearHechizo());
		comandante.agregarHechizo(new CreadorProtego().crearHechizo());
		
		return comandante;
	}
}
