package fabrica;

import hechizo.Protego;
import hechizo.Hechizo;

public class CreadorProtego implements CreadorHechizo{

	@Override
	public Hechizo crearHechizo() {
		return new Protego();
	}
}
