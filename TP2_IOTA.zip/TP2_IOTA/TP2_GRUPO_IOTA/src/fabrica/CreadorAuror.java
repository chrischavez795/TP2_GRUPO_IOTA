package fabrica;

import personaje.DatosErroneosExcepcion;
import personaje.*;

public class CreadorAuror implements CreadorPersonaje{
	
	@Override
	public Personaje crearPersonaje(String nombre, int nivelMagia, int puntosVida) throws DatosErroneosExcepcion{
		
		Personaje auror = new Auror(nombre, nivelMagia, puntosVida); 
		
		// Hechizos iniciales usando el factory method
		auror.agregarHechizo(new CreadorExpelliarmus().crearHechizo());
		auror.agregarHechizo(new CreadorProtego().crearHechizo());
		auror.agregarHechizo(new CreadorExpectoPatronum().crearHechizo());
	    
	    return auror;
	}

}
