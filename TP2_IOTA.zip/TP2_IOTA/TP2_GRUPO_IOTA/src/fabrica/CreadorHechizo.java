package fabrica;

import hechizo.Hechizo;

public interface CreadorHechizo {

	public Hechizo crearHechizo();
}
