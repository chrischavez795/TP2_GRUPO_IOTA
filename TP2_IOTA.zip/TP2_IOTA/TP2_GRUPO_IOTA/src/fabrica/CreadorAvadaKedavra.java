package fabrica;

import hechizo.AvadaKedavra;
import hechizo.Hechizo;

public class CreadorAvadaKedavra implements CreadorHechizo {

	@Override
	public Hechizo crearHechizo() {
		return new AvadaKedavra();
	}
}
