package fabrica;

//Se utiliza el patrón Factory Method para centralizar la creación de personajes

import personaje.Personaje;
import personaje.DatosErroneosExcepcion;

public interface CreadorPersonaje {

	public Personaje crearPersonaje(String nombre, int nivelMagia, int puntosVida) throws DatosErroneosExcepcion;
}
