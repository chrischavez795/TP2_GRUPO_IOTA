package fabrica;

import personaje.DatosErroneosExcepcion;
import personaje.*;

public class CreadorEstudiante implements CreadorPersonaje{

	@Override
	public Personaje crearPersonaje(String nombre, int nivelMagia, int puntosVida) throws DatosErroneosExcepcion{

		Personaje estudiante = new Estudiante(nombre, nivelMagia, puntosVida);
		
		// Hechizos iniciales
		estudiante.agregarHechizo(new CreadorExpelliarmus().crearHechizo());
		estudiante.agregarHechizo(new CreadorProtego().crearHechizo());
		
		return estudiante;
	}
}
