package fabrica;

import personaje.*;

public class Reclutador {

	public static Personaje crearAuror(String nombre, int nivel, int vida) throws DatosErroneosExcepcion {

		return new CreadorAuror().crearPersonaje(nombre, nivel, vida);
	}

	public static Personaje crearEstudiante(String nombre, int nivel, int vida) throws DatosErroneosExcepcion {

		return new CreadorEstudiante().crearPersonaje(nombre, nivel, vida);
	}

	public static Personaje crearProfesor(String nombre, int nivel, int vida) throws DatosErroneosExcepcion {

		return new CreadorProfesor().crearPersonaje(nombre, nivel, vida);
	}

	public static Personaje crearSeguidor(String nombre, int nivel, int vida) throws DatosErroneosExcepcion {

		return new CreadorSeguidor().crearPersonaje(nombre, nivel, vida);
	}

	public static Personaje crearComandante(String nombre, int nivel, int vida) throws DatosErroneosExcepcion {

		return new CreadorComandante().crearPersonaje(nombre, nivel, vida);
	}

}