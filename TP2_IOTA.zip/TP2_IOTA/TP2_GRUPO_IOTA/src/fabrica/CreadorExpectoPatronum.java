package fabrica;

import hechizo.ExpectoPatronum;
import hechizo.Hechizo;

public class CreadorExpectoPatronum implements CreadorHechizo{

	@Override
	public Hechizo crearHechizo() {
		return new ExpectoPatronum();
	}
}
