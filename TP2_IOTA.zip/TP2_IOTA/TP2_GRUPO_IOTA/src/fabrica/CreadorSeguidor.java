package fabrica;

import personaje.DatosErroneosExcepcion;
import personaje.*;

public class CreadorSeguidor implements CreadorPersonaje{

	@Override
	public Personaje crearPersonaje(String nombre, int nivelMagia, int puntosVida) throws DatosErroneosExcepcion{

		Personaje seguidor = new Seguidor(nombre, nivelMagia, puntosVida);
		
		// Hechizos iniciales
		seguidor.agregarHechizo(new CreadorExpelliarmus().crearHechizo());
		seguidor.agregarHechizo(new CreadorAvadaKedavra().crearHechizo());
		
		return seguidor;
	}
}
