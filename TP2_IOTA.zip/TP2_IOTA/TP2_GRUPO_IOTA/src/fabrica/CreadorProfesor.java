package fabrica;

import personaje.DatosErroneosExcepcion;
import personaje.*;

public class CreadorProfesor implements CreadorPersonaje{

	@Override
	public Personaje crearPersonaje(String nombre, int nivelMagia, int puntosVida) throws DatosErroneosExcepcion{
		
		Personaje profesor = new Profesor(nombre, nivelMagia, puntosVida);
		
		// Hechizos iniciales
		profesor.agregarHechizo(new CreadorExpelliarmus().crearHechizo());
		profesor.agregarHechizo(new CreadorProtego().crearHechizo());
		profesor.agregarHechizo(new CreadorExpectoPatronum().crearHechizo());
		
		return profesor;
	}
}
