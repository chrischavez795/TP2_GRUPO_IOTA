package batalla;

import personaje.*;
import hechizo.*;
import hechizo.Hechizo.TipoObjetivo;

import java.util.*;

public class Batallon {

	private List<Personaje> listaPersonajes;
	private Map<Personaje, List<Hechizo>> hechizosLanzados;
	private Set<Hechizo> hechizosUsadosEnRonda;
	private int indiceAtacante;

	public Batallon() {
		this.listaPersonajes = new ArrayList<Personaje>();
		this.hechizosLanzados = new HashMap<Personaje, List<Hechizo>>();
		this.hechizosUsadosEnRonda = new HashSet<Hechizo>();
		this.indiceAtacante = 0;
	}

	public void agregarPersonaje(Personaje p) {

		listaPersonajes.add(p);
	}

	public boolean tienePersonajesSaludables() {

		for (Personaje p : listaPersonajes) {
			if (p.estaVivo()) {
				return true;
			}
		}
		return false;
	}

	public Personaje obtenerPersonajeVivo() {

		for (Personaje p : listaPersonajes) {
			if (p.estaVivo()) {
				return p;
			}
		}

		return null;
	}

	public Personaje obtenerSiguienteAtacanteVivo() {

		if (listaPersonajes.isEmpty()) {
			return null;
		}

		for (int i = 0; i < listaPersonajes.size(); i++) {

			Personaje posibleAtacante = listaPersonajes.get(indiceAtacante);

			indiceAtacante++;

			if (indiceAtacante >= listaPersonajes.size()) {
				indiceAtacante = 0;
			}

			if (posibleAtacante.getPuntosVida() > 0) {
				return posibleAtacante;
			}
		}

		return null;
	}

	public Hechizo obtenerHechizoDisponible(Personaje atacante) {

		for (Hechizo h : atacante.getListaHechizos()) {
			if (!hechizosUsadosEnRonda.contains(h)) {
				return h;
			}
		}

		return null;
	}

	public Personaje elegirObjetivo(Personaje atacante, Hechizo hechizo, Batallon batallonDestino) {

		if (hechizo.getTipoObjetivo() == TipoObjetivo.ENEMIGO) {
			return batallonDestino.obtenerPersonajeVivo();
		}

		if (hechizo.getTipoObjetivo() == TipoObjetivo.PROPIO) {
			return atacante;
		}

		if (hechizo.getTipoObjetivo() == TipoObjetivo.ALIADO) {
			return this.obtenerPersonajeVivo();
		}

		return null;
	}

	public void registrarHechizoLanzado(Personaje atacante, Hechizo hechizo) {

		List<Hechizo> historial = hechizosLanzados.get(atacante);

		if (historial == null) {
			historial = new ArrayList<>();
			hechizosLanzados.put(atacante, historial);
		}

		historial.add(hechizo);

		hechizosUsadosEnRonda.add(hechizo);
	}

	public void atacar(Batallon batallonDestino) {

		Personaje atacante = this.obtenerSiguienteAtacanteVivo();

		if (atacante == null) {
			return;
		}

		if (atacante.getListaHechizos().isEmpty()) {
			System.out.println(atacante.getNombre() + " no tiene hechizos para lanzar.");
			return;
		}

		Hechizo hechizo = obtenerHechizoDisponible(atacante);

		if (hechizo == null) {
			System.out.println(atacante.getNombre() + " ya usó todos sus hechizos en esta ronda.");
			return;
		}

		Personaje objetivo = elegirObjetivo(atacante, hechizo, batallonDestino);

		if (objetivo == null) {
			return;
		}

		System.out.println(atacante.getNombre() + " lanza " + hechizo.getClass().getSimpleName() + " sobre "
				+ objetivo.getNombre());

		int vidaAntes = objetivo.getPuntosVida();

		hechizo.ejecutar(atacante, objetivo);

		if (hechizo.getTipoObjetivo() == Hechizo.TipoObjetivo.ENEMIGO) {

			int danioCausado = vidaAntes - objetivo.getPuntosVida();

			System.out.println(
					atacante.getNombre() + " le causa " + danioCausado + " puntos de daño a " + objetivo.getNombre());

			System.out.println(objetivo.getNombre() + " tiene " + objetivo.getPuntosVida() + " puntos de vida");

			if (!objetivo.estaVivo()) {
				System.out.println(objetivo.getNombre() + " ha muerto.");
				batallonDestino.avisarAliadoDerrotado();
			}
		}

		registrarHechizoLanzado(atacante, hechizo);
	}

	public void reiniciarRonda() {
		hechizosUsadosEnRonda.clear();
	}

	public Map<Personaje, List<Hechizo>> getHechizosLanzados() {
		return hechizosLanzados;
	}

	public void avisarAliadoDerrotado() {

		for (Personaje p : listaPersonajes) {
			p.aliadoDerrotado();
		}

	}

	public void atacarTodos(Batallon enemigo) {

		int cantidad = listaPersonajes.size();

		for (int i = 0; i < cantidad; i++) {

			if (this.tienePersonajesSaludables()) {
				atacar(enemigo);
			}
		}
	}

	public void mostrarEstado() {

		for (Personaje p : listaPersonajes) {
			System.out.println(p.getNombre() + " HP: " + p.getPuntosVida());
		}
	}
	
	public List<Personaje> getListaPersonajes(){
	    return listaPersonajes;
	}

}
